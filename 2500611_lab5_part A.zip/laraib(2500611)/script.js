const form = document.getElementById("studentForm");

const fullName = document.getElementById("fullName");
const email = document.getElementById("email");
const program = document.getElementById("program");
const semester = document.getElementById("semester");

const previewName = document.getElementById("previewName");
const previewEmail = document.getElementById("previewEmail");
const previewProgram = document.getElementById("previewProgram");
const previewSemester = document.getElementById("previewSemester");

const previewCard = document.querySelector("#previewCard");
const themeButton = document.querySelector("#themeButton");
const studentList = document.querySelector("#studentList");


fullName.addEventListener("input", function () {
    if (fullName.value === "") {
        previewName.textContent = "Your Name";
    } else {
        previewName.textContent = fullName.value;
    }
});


email.addEventListener("input", function () {
    if (email.value === "") {
        previewEmail.textContent = "example@email.com";
    } else {
        previewEmail.textContent = email.value;
    }
});


program.addEventListener("change", function () {
    if (program.value === "") {
        previewProgram.textContent = "Your Program";
    } else {
        previewProgram.textContent = program.value;
    }
});


semester.addEventListener("input", function () {
    if (semester.value === "") {
        previewSemester.textContent = "-";
    } else {
        previewSemester.textContent = semester.value;
    }
});


form.addEventListener("submit", function (event) {

    event.preventDefault();

    document.getElementById("nameError").textContent = "";
    document.getElementById("emailError").textContent = "";
    document.getElementById("programError").textContent = "";
    document.getElementById("semesterError").textContent = "";

    let isValid = true;


    if (fullName.value.trim() === "") {
        document.getElementById("nameError").textContent =
            "Full Name is required.";

        isValid = false;
    }


    if (email.value.trim() === "") {
        document.getElementById("emailError").textContent =
            "Email is required.";

        isValid = false;
    }


    if (program.value === "") {
        document.getElementById("programError").textContent =
            "Please select a program.";

        isValid = false;
    }


    if (
        semester.value === "" ||
        semester.value < 1 ||
        semester.value > 8
    ) {
        document.getElementById("semesterError").textContent =
            "Semester must be between 1 and 8.";

        isValid = false;
    }


    if (isValid === true) {

        const listItem = document.createElement("li");

        listItem.textContent =
            fullName.value +
            " | " +
            email.value +
            " | " +
            program.value +
            " | Semester " +
            semester.value;

        studentList.appendChild(listItem);

        form.reset();

        previewName.textContent = "Your Name";
        previewEmail.textContent = "example@email.com";
        previewProgram.textContent = "Your Program";
        previewSemester.textContent = "-";
    }

});


themeButton.addEventListener("click", function () {

    previewCard.classList.toggle("dark");

});